package org.example;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ConfigBDD configBDD = new ConfigBDD();

        try {
            Connection connection = configBDD.getConnection();
            System.out.println("Connexion à la base de données établie.");

            boolean running = true;
            while (running) {
                System.out.println("\nMenu:");
                System.out.println("1. Enregistrer les informations");
                System.out.println("2. Calculer et afficher les moyennes des étudiants par matière");
                System.out.println("3. Afficher le meilleur étudiant par matière");
                System.out.println("4. Afficher les matières à retravailler pour chaque étudiant");
                System.out.println("5. Modifier une note erronée déjà saisie");
                System.out.println("6. Quitter");
                System.out.print("Choisissez une option: ");
                int option = scanner.nextInt();
                scanner.nextLine();

                switch (option) {
                    case 1:
                        enregistrerDansFichier enregistreur = new enregistrerDansFichier();
                        enregistreur.enregistrerInformations(connection, scanner);
                        break;
                    case 2:
                        calculerEtAfficherMoyennes.calculerEtAfficherMoyennes(connection);
                        break;
                    case 3:
                        afficherMeilleurEtudiantParMatiere.afficherMeilleurEtudiantParMatiere(connection);
                        break;
                    case 4:
                        afficherMatieresARetravailler.afficherMatieresARetravailler(connection);
                        break;
                    case 5:
                        modifierNoteErronee.modifierNoteErronee(connection, scanner);
                        break;
                    case 6:
                        running = false;
                        break;
                    default:
                        System.out.println("Option invalide !");
                }
            }

            connection.close();
            System.out.println("Connexion à la base de données fermée.");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        scanner.close();
    }


}
