package org.example;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class calculerEtAfficherMoyennes {
    public static void calculerEtAfficherMoyennes(Connection connection) throws SQLException {
        String query = "SELECT Student.id AS student_id, Student.firstName, Student.lastName, " +
                "AVG(Grade.grade) AS average " +
                "FROM Grade " +
                "JOIN Student ON Grade.student_id = Student.id " +
                "GROUP BY Student.id";
        PreparedStatement statement = connection.prepareStatement(query);
        ResultSet resultSet = statement.executeQuery();

        Map<String, Double> moyennes = new HashMap<>();

        System.out.println("Moyennes des étudiants par matière:");
        while (resultSet.next()) {
            String studentId = resultSet.getString("student_id");
            String firstName = resultSet.getString("firstName");
            String lastName = resultSet.getString("lastName");
            double average = resultSet.getDouble("average");

            moyennes.put(studentId, average);

            System.out.println("Étudiant: " + firstName + " " + lastName + " (ID: " + studentId + "), Moyenne: " + average);
        }

        resultSet.close();
        statement.close();

    }

}
