package org.example;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class enregistrerDansFichier {

    public static void enregistrerInformations(Connection connection, Scanner scanner) {
        System.out.println("Enregistrer les informations:");

        System.out.print("Entrez l'ID de l'étudiant: ");
        String studentId = scanner.nextLine();
        System.out.print("Entrez le nom de famille de l'étudiant: ");
        String studentName = scanner.nextLine();
        System.out.print("Entrez le prénom de l'étudiant: ");
        String lastName = scanner.nextLine();
        System.out.print("Entrez le sujet (1 ou 2): ");
        String subject = scanner.nextLine();
        System.out.print("Entrez la note de l'étudiant: ");
        int grade = scanner.nextInt();
        scanner.nextLine();

        enregistrerDansBaseDeDonnees(connection, studentId, studentName, lastName, subject, grade);
        enregistrerDansFichierAvecTimestamp(studentId, studentName, lastName, subject, grade);
    }


    private static void enregistrerDansBaseDeDonnees(Connection connection, String studentId, String firstName, String lastName, String subject, int grade) {
        try {
            // Vérifier si l'étudiant existe déjà dans la base de données
            String studentQuery = "SELECT id FROM Student WHERE id = ?";
            PreparedStatement studentStatement = connection.prepareStatement(studentQuery);
            studentStatement.setString(1, studentId);
            ResultSet studentResultSet = studentStatement.executeQuery();

            // Si l'étudiant n'existe pas, l'insérer dans la table Student
            if (!studentResultSet.next()) {
                String insertStudentQuery = "INSERT INTO Student (id, firstName, lastName) VALUES (?, ?, ?)";
                PreparedStatement insertStudentStatement = connection.prepareStatement(insertStudentQuery);
                insertStudentStatement.setString(1, studentId);
                insertStudentStatement.setString(2, firstName);
                insertStudentStatement.setString(3, lastName);
                insertStudentStatement.executeUpdate();
            }

            // Vérifier si la matière existe déjà dans la base de données en utilisant son nom
            String subjectIdQuery = "SELECT id FROM Subject WHERE name = ?";
            PreparedStatement subjectIdStatement = connection.prepareStatement(subjectIdQuery);
            subjectIdStatement.setString(1, subject);
            ResultSet subjectIdResultSet = subjectIdStatement.executeQuery();

            String subjectId;
            if (subjectIdResultSet.next()) {
                subjectId = subjectIdResultSet.getString("id");
            } else {
                // Si la matière n'existe pas, l'insérer dans la table Subject
                String insertSubjectQuery = "INSERT INTO Subject (name, factor) VALUES (?, 1)"; // Valeur par défaut de factor
                PreparedStatement insertSubjectStatement = connection.prepareStatement(insertSubjectQuery, PreparedStatement.RETURN_GENERATED_KEYS);
                insertSubjectStatement.setString(1, subject);
                insertSubjectStatement.executeUpdate();
                ResultSet generatedKeys = insertSubjectStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    subjectId = generatedKeys.getString(1);
                } else {
                    throw new SQLException("Échec de la récupération de l'ID de la matière nouvellement insérée.");
                }
            }

            // Insérer les données dans la table Grade
            String gradeQuery = "INSERT INTO Grade (student_id, subject_id, grade) VALUES (?, ?, ?)";
            PreparedStatement gradeStatement = connection.prepareStatement(gradeQuery);
            gradeStatement.setString(1, studentId);
            gradeStatement.setString(2, subjectId);
            gradeStatement.setInt(3, grade);
            gradeStatement.executeUpdate();

            System.out.println("Les informations ont été enregistrées dans la base de données avec succès !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private static void enregistrerDansFichierAvecTimestamp(String studentId, String firstName, String lastName, String subject, int grade) {
        try {
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
            String timestamp = now.format(formatter);

            FileWriter writer = new FileWriter("enregistrements.txt", true);
            writer.write("Timestamp: " + timestamp + ", ID étudiant: " + studentId +
                    ", Prénom: " + firstName + ", Nom: " + lastName + ", Matière: " + subject +
                    ", Note: " + grade + "\n");
            writer.close();
            System.out.println("Les informations ont été enregistrées dans le fichier avec succès !");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Erreur lors de l'enregistrement des informations dans le fichier.");
        }
    }
}
