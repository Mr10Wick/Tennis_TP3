package org.example;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class afficherMeilleurEtudiantParMatiere {
    public static void afficherMeilleurEtudiantParMatiere(Connection connection) throws SQLException {
        String query = "SELECT Subject.id AS subject_id, Subject.name AS subject_name, " +
                "BestStudent.student_id, BestStudent.firstName, BestStudent.lastName, " +
                "BestStudent.average " +
                "FROM Subject " +
                "JOIN (" +
                "   SELECT Grade.subject_id, " +
                "          Student.id AS student_id, Student.firstName, Student.lastName, " +
                "          AVG(Grade.grade) AS average " +
                "   FROM Grade " +
                "   JOIN Student ON Grade.student_id = Student.id " +
                "   GROUP BY Grade.subject_id, Student.id " +
                "   ORDER BY AVG(Grade.grade) DESC " +
                "   LIMIT 1" +
                ") AS BestStudent ON Subject.id = BestStudent.subject_id";

        PreparedStatement statement = connection.prepareStatement(query);
        ResultSet resultSet = statement.executeQuery();

        System.out.println("Meilleur étudiant par matière:");
        while (resultSet.next()) {
            String subjectId = resultSet.getString("subject_id");
            String subjectName = resultSet.getString("subject_name");
            String studentId = resultSet.getString("student_id");
            String firstName = resultSet.getString("firstName");
            String lastName = resultSet.getString("lastName");
            double average = resultSet.getDouble("average");

            System.out.println("Matière: " + subjectName + ", ID de la matière: " + subjectId +
                    ", Meilleur étudiant: " + firstName + " " + lastName +
                    " (ID: " + studentId + "), Moyenne: " + average);
        }

        resultSet.close();
        statement.close();
    }
}
