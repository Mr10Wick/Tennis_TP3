package org.example;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class modifierNoteErronee {
    public static void modifierNoteErronee(Connection connection, Scanner scanner) throws SQLException {
        System.out.println("Modifier une note erronée déjà saisie:");
        System.out.print("Entrez l'ID de l'étudiant: ");
        String studentId = scanner.nextLine();
        System.out.print("Entrez l'ID de la matière: ");
        String subjectId = scanner.nextLine();
        System.out.print("Entrez la nouvelle note: ");
        int newGrade = scanner.nextInt();
        scanner.nextLine(); // consommer la nouvelle ligne

        String query = "UPDATE Grade SET grade = ? WHERE student_id = ? AND subject_id = ? AND grade < 15 LIMIT 1";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, newGrade);
        statement.setString(2, studentId);
        statement.setString(3, subjectId);

        int rowsUpdated = statement.executeUpdate();
        if (rowsUpdated > 0) {
            System.out.println("Note mise à jour avec succès !");
        } else {
            System.out.println("Erreur lors de la mise à jour de la note.");
        }

        // Afficher les matières à retravailler pour l'étudiant
        afficherMatieresARetravailler(connection);
    }

    private static void afficherMatieresARetravailler(Connection connection) throws SQLException {
        String query = "SELECT Grade.student_id, Student.firstName, Student.lastName, Grade.subject_id, AVG(Grade.grade) AS average " +
                "FROM Grade " +
                "JOIN Student ON Grade.student_id = Student.id " +
                "WHERE AVG(Grade.grade) < 15 " +
                "GROUP BY Grade.student_id, Grade.subject_id";
        PreparedStatement statement = connection.prepareStatement(query);
        ResultSet resultSet = statement.executeQuery();

        System.out.println("Matieres à retravailler pour chaque étudiant (note moyenne en dessous de 15):");
        while (resultSet.next()) {
            String studentId = resultSet.getString("student_id");
            String firstName = resultSet.getString("firstName");
            String lastName = resultSet.getString("lastName");
            String subjectId = resultSet.getString("subject_id");
            double average = resultSet.getDouble("average");

            System.out.println("Étudiant: " + firstName + " " + lastName + " (" + studentId + "), Matière: " + subjectId + ", Moyenne: " + average);
        }
    }
}
